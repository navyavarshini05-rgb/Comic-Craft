# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI web application based on the supplied project documentation. It accepts a story prompt plus character, setting, tone, art-style and panel-count preferences; Gemini generates a structured panel-by-panel story, Gemini image generation creates the artwork, and ReportLab exports the finished comic as a PDF.

## Architecture

Browser (HTML/CSS/JS) → FastAPI → Gemini text model → structured ComicStory → Gemini image model per panel → generated PNG files → ReportLab PDF.

The original documentation specifies FastAPI, Gemini, image generation, HTML/CSS/JavaScript and PDF export. Current Gemini APIs are used here instead of the older Gemini 1.5/Imagen references.

## Requirements

- Python 3.11 recommended
- VS Code
- A Google Gemini API key
- Internet access for Gemini API calls

Local CPU/GPU Stable Diffusion is intentionally not required for the default setup because it makes installation much heavier. The architecture keeps image generation behind `GeminiService`, so a Diffusers provider can be added later without changing the frontend or API contract.

## Windows / VS Code setup

1. Open this folder in VS Code.
2. Open Terminal → New Terminal.
3. Create an environment:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

4. Copy `.env.example` to `.env`.
5. Put your Gemini API key in `.env`:

```env
GEMINI_API_KEY=your_real_key_here
```

6. Run:

```powershell
uvicorn app.main:app --reload
```

7. Open `http://127.0.0.1:8000`.

## Test

In a second terminal with the environment active:

```powershell
pytest -q
```

Health check: open `http://127.0.0.1:8000/health`.

API docs: open `http://127.0.0.1:8000/docs`.

## API

`POST /api/comics`

Example JSON:

```json
{
  "prompt": "A brave fox explores an enchanted forest and discovers a forgotten library.",
  "character_name": "Lumi",
  "setting": "an enchanted forest",
  "tone": "mysterious",
  "art_style": "comic book",
  "panels": 4
}
```

The response contains the generated story, panel image URLs and a PDF URL.

## Troubleshooting

- `GEMINI_API_KEY is not configured`: check `.env`, then restart Uvicorn.
- Image generation errors: check the API key's access/quota and the configured image model.
- Slow generation: image generation is performed once per panel; 4–6 panels can take several minutes.
- `python` command not found: use `py` on Windows or install Python 3.11 and enable PATH.

## Project tree

```text
comiccraft/
├── app/
│   ├── main.py
│   ├── config.py
│   ├── routes.py
│   ├── schemas.py
│   ├── services/
│   │   ├── gemini.py
│   │   └── pdf_exporter.py
│   ├── templates/index.html
│   └── static/
│       ├── style.css
│       └── app.js
├── generated/
├── tests/test_app.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```
