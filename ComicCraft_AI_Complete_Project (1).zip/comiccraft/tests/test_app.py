from fastapi.testclient import TestClient
from app.main import app

client=TestClient(app)

def test_health():
    r=client.get('/health')
    assert r.status_code==200
    assert r.json()['status']=='ok'

def test_home():
    r=client.get('/')
    assert r.status_code==200
    assert 'ComicCraft' in r.text

def test_validation():
    r=client.post('/api/comics',json={'prompt':'x'})
    assert r.status_code in (422,500)
