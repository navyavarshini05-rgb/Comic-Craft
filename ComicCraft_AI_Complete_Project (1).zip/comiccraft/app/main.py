from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.config import BASE_DIR, settings
from app.routes import router

app = FastAPI(title="ComicCraft", version="1.0.0", description="AI Comic Story Creator")
app.state.templates = Jinja2Templates(directory=str(BASE_DIR / "app" / "templates"))
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "app" / "static")), name="static")
app.mount("/generated", StaticFiles(directory=str(settings.output_path)), name="generated")
app.include_router(router)
