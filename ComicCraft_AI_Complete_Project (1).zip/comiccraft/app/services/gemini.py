from pathlib import Path
from app.config import settings
from app.schemas import ComicRequest, ComicStory

class GeminiService:
    def __init__(self):
        if not settings.gemini_api_key:
            raise RuntimeError("GEMINI_API_KEY is not configured. Copy .env.example to .env and add your key.")
        try:
            from google import genai
        except ImportError as exc:
            raise RuntimeError("Google GenAI SDK is missing. Run: pip install -r requirements.txt") from exc
        self.client = genai.Client(api_key=settings.gemini_api_key)

    def create_story(self, req: ComicRequest) -> ComicStory:
        prompt = f"""
Create a cohesive {req.panels}-panel comic story.
User story idea: {req.prompt}
Main character: {req.character_name}
Setting: {req.setting}
Tone: {req.tone}
Visual style: {req.art_style}

Requirements:
- Return exactly {req.panels} panels.
- Maintain character and setting continuity.
- Each panel needs concise narration, natural dialogue, a scene description, and a detailed image prompt.
- Image prompts must describe composition, characters, action, lighting, environment, and the requested visual style.
- Do not put speech bubbles or written words inside generated artwork; dialogue is rendered separately by the application.
"""
        from google.genai import types
        from google.genai import types
        response = self.client.models.generate_content(
            model=settings.text_model,
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=ComicStory,
                temperature=0.9,
            ),
        )
        if getattr(response, "parsed", None):
            return response.parsed
        return ComicStory.model_validate_json(response.text)

    def create_image(self, image_prompt: str, output: Path) -> None:
        response = self.client.models.generate_content(
            model=settings.image_model,
            contents=[image_prompt],
            config=types.GenerateContentConfig(
                response_modalities=["IMAGE"],
                response_format={"image": {"aspect_ratio": "16:9"}},
            ),
        )
        for part in getattr(response, "parts", []) or []:
            if getattr(part, "inline_data", None):
                image = part.as_image()
                image.save(output)
                return
        raise RuntimeError("Gemini returned no image data for this panel.")
