from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from app.schemas import ComicStory

class ComicPDFExporter:
    def export(self, story: ComicStory, image_paths: list[Path], output: Path) -> None:
        c = canvas.Canvas(str(output), pagesize=A4)
        width, height = A4
        c.setTitle(story.title)
        for idx, panel in enumerate(story.panels):
            c.setFont("Helvetica-Bold", 20)
            c.drawString(20*mm, height-25*mm, story.title)
            c.setFont("Helvetica-Bold", 14)
            c.drawString(20*mm, height-38*mm, f"Panel {panel.panel_number}: {panel.title}")
            img = image_paths[idx]
            if img.exists():
                iw, ih = ImageReader(str(img)).getSize()
                max_w, max_h = width-40*mm, 105*mm
                scale = min(max_w/iw, max_h/ih)
                dw, dh = iw*scale, ih*scale
                c.drawImage(str(img), (width-dw)/2, height-48*mm-dh, width=dw, height=dh, preserveAspectRatio=True, mask='auto')
            y = height-60*mm-110*mm
            c.setFont("Helvetica", 10)
            text = c.beginText(20*mm, max(y, 45*mm))
            text.setLeading(14)
            for line in wrap(panel.narration, 95): text.textLine(line)
            for dialogue in panel.dialogue:
                for line in wrap(f"Dialogue: {dialogue}", 95): text.textLine(line)
            c.drawText(text)
            c.showPage()
        c.save()

def wrap(text: str, width: int):
    words, lines, current = text.split(), [], ""
    for word in words:
        if len(current) + len(word) + 1 > width:
            lines.append(current)
            current = word
        else:
            current = (current + " " + word).strip()
    if current: lines.append(current)
    return lines
