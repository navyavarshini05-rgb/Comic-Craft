import uuid
from pathlib import Path
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse
from app.config import settings
from app.schemas import ComicRequest, GeneratedComic
from app.services.gemini import GeminiService
from app.services.pdf_exporter import ComicPDFExporter

router = APIRouter()

@router.get("/")
async def home(request: Request):
    return request.app.state.templates.TemplateResponse("index.html", {"request": request})

@router.get("/health")
async def health():
    return {"status": "ok", "gemini_configured": bool(settings.gemini_api_key)}

@router.post("/api/comics", response_model=GeneratedComic)
async def create_comic(req: ComicRequest):
    if not settings.gemini_api_key:
        raise HTTPException(500, "GEMINI_API_KEY is not configured.")
    try:
        service = GeminiService()
        story = service.create_story(req)
        comic_id = uuid.uuid4().hex
        image_paths = []
        image_urls = []
        for panel in story.panels:
            path = settings.output_path / f"{comic_id}_panel_{panel.panel_number}.png"
            service.create_image(panel.image_prompt, path)
            image_paths.append(path)
            image_urls.append(f"/generated/{path.name}")
        pdf_path = settings.output_path / f"{comic_id}.pdf"
        ComicPDFExporter().export(story, image_paths, pdf_path)
        return GeneratedComic(id=comic_id, story=story, image_urls=image_urls, pdf_url=f"/api/comics/{comic_id}/pdf")
    except Exception as exc:
        raise HTTPException(500, str(exc)) from exc

@router.get("/api/comics/{comic_id}/pdf")
async def download_pdf(comic_id: str):
    path = settings.output_path / f"{comic_id}.pdf"
    if not path.exists(): raise HTTPException(404, "Comic PDF not found")
    return FileResponse(path, media_type="application/pdf", filename=f"comiccraft-{comic_id}.pdf")
