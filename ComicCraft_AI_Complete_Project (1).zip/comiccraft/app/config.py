from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    gemini_api_key: str = ""
    text_model: str = "gemini-2.5-flash"
    image_model: str = "gemini-2.5-flash-image"
    output_dir: str = "generated"
    max_panels: int = 6
    model_config = SettingsConfigDict(env_file=BASE_DIR / ".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def output_path(self) -> Path:
        p = BASE_DIR / self.output_dir
        p.mkdir(parents=True, exist_ok=True)
        return p

settings = Settings()
