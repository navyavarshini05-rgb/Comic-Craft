from pydantic import BaseModel, Field

class Panel(BaseModel):
    panel_number: int = Field(ge=1)
    title: str
    narration: str
    dialogue: list[str] = Field(default_factory=list)
    scene_description: str
    image_prompt: str

class ComicStory(BaseModel):
    title: str
    logline: str
    panels: list[Panel]

class ComicRequest(BaseModel):
    prompt: str = Field(min_length=5, max_length=2000)
    character_name: str = Field(default="Alex", max_length=80)
    setting: str = Field(default="an enchanted forest", max_length=160)
    tone: str = Field(default="adventurous", max_length=80)
    art_style: str = Field(default="comic book", max_length=120)
    panels: int = Field(default=4, ge=2, le=6)

class GeneratedComic(BaseModel):
    id: str
    story: ComicStory
    image_urls: list[str]
    pdf_url: str | None = None
